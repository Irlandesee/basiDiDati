package datamodel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import com.googlecode.jeneratedata.people.FemaleNameGenerator;
import com.googlecode.jeneratedata.people.LastNameGenerator;
import com.googlecode.jeneratedata.people.MaleNameGenerator;

import database.DbHelper;

public class Studente {

	private int matricola;
	private String cognome;
	private String nome;
	private int eta;
	
	public Studente(int matricola, String cognome, String nome, int eta) {
		
		this.matricola = matricola;
		this.cognome = cognome;
		this.nome = nome;
		this.eta = eta;
	}
	
	public int getMatricola() {
		return matricola;
	}
	public void setMatricola(int matricola) {
		this.matricola = matricola;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getEta() {
		return eta;
	}
	public void setEta(int eta) {
		this.eta = eta;
	}
	
	public static Studente generateStudente() {

		java.util.Random randomGenerator = new Random();
		
		int matricola = randomGenerator.nextInt(999999);
		int eta = randomGenerator.nextInt(30) + 20;

		LastNameGenerator lastNameGenerator = new LastNameGenerator();		
		String cognome = lastNameGenerator.generate();
		String nome;
		
		FemaleNameGenerator femaleNameGenerator = new FemaleNameGenerator();
		MaleNameGenerator maleNameGenerator = new MaleNameGenerator();
		if (randomGenerator.nextInt(100) > 65) {
			nome = maleNameGenerator.generate();
		} else {
			nome = femaleNameGenerator.generate();
		}

		return new Studente(matricola, cognome, nome, eta);
	}

	private static PreparedStatement fetchStatement = null;
	
	private static PreparedStatement getFetchStatement() throws SQLException {
		
		if (fetchStatement == null) {

			Connection connection = DbHelper.getConnection();
			fetchStatement = connection.prepareStatement("SELECT * FROM Studenti WHERE matricola = ?");
		}
		
		return fetchStatement;
	}
	
	/* In uno scenario applicativo � bene prevedere un numero di metodi di estrazione
	 * dal DBMS (metodi fetch) che estraggono pi� di una tupla e mappano il result set
	 * in un numero molteplice di istanze della classe
	 * 
	 * public static List<Studente> fetchStudenteByNome(String nome){ return null; }
	 */
	
	public static Studente fetchStudente(int matricola) throws SQLException {

		/* Opzione A */
		PreparedStatement prepared = getFetchStatement();
		prepared.setInt(1, matricola);
		ResultSet rs = prepared.executeQuery();
		
		/* Opzione B 
		 * 
		 * Statement statement = DbHelper.getStatement();
		 * ResultSet rs = statement.executeQuery("SELECT * FROM Studenti WHERE matricola = " + matricola);
		 */
		
		while (rs.next()) {
			
			return new Studente(rs.getInt("matricola"), rs.getString("cognome"),
									rs.getString("nome"), rs.getInt("eta"));
		}
		
		return null;
	}
	
	public static List<Studente> fetchAll() throws SQLException {

		Statement statement = DbHelper.getStatement();
		ResultSet rs = statement.executeQuery("SELECT * FROM Studenti");

		List<Studente> studenti = new LinkedList<Studente>();
		
		while (rs.next()) {
			
			studenti.add( new Studente(rs.getInt("matricola"), rs.getString("cognome"),
									rs.getString("nome"), rs.getInt("eta")) );
		}
		
		return studenti;
	}
	
	public String toString() {
		
		return this.cognome + ", " +this.nome + " (matr: "+this.matricola+", et�: "+this.eta+")";
	}
}
