package datamodel;

import java.util.ArrayList;
import java.util.Random;

public class DataModel {
  
  private ArrayList<Studente> studenti;
  private ArrayList<Esame> esami;

  public DataModel() {

    studenti = new ArrayList<Studente>();
    esami = new ArrayList<Esame>();

  }

  public void populateModel(int numStudenti, int numEsami) {

    for (int i=0; i<numStudenti; i++) {
      
      studenti.add( Studente.generateStudente() );
    }

    java.util.Random randomGenerator = new Random();
    for (int i=0; i<numEsami; i++) {

      Studente s = studenti.get( randomGenerator.nextInt(numStudenti) );
      esami.add( Esame.generateEsame(s.getMatricola()) );
    }
  }

  public ArrayList<Studente> getStudenti() {
    return studenti;
  }

  public ArrayList<Esame> getEsami() {
    return esami;
  }

}