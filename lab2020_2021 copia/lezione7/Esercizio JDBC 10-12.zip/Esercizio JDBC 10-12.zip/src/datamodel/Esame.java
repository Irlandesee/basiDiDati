package datamodel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import com.googlecode.jeneratedata.dates.DateGenerator;

import database.DbHelper;

public class Esame {

	private int codiceCorso;
	private int studente;
	private Date data;
	private int voto;
	
	/* Ogni istanza della classe Esame corrisponde ad una singola tupla
	 * contenuta nella tabella 'Esami' del DBMS.
	 * Per questo motivo, l'attributo 'studente' della classe � di tipo
	 * intero e NON di tipo Studente.
	 */
	public Esame(int codiceCorso, int studente, Date data, int voto) {

		this.codiceCorso = codiceCorso;
		this.studente = studente;
		this.data = data;
		this.voto = voto;
	}	
	
	public int getCodiceCorso() {
		return codiceCorso;
	}
	public void setCodiceCorso(int codiceCorso) {
		this.codiceCorso = codiceCorso;
	}
	
	/* questo metodo getter restituisce il valore intero dell'attributo 'studente' 
	public int getStudente() {
		return studente;
	}
	*/
	
	public Studente getStudente() throws SQLException {
		
		return Studente.fetchStudente(this.studente);
	}
	
	public void setStudente(int studente) {
		this.studente = studente;
	}
	public Date getData() {
		return data;
	}
	public void setData(Date data) {
		this.data = data;
	}
	public int getVoto() {
		return voto;
	}
	public void setVoto(int voto) {
		this.voto = voto;
	}

	public static Esame generateEsame(int studente) {

		java.util.Random randomGenerator = new Random();

		Calendar start=Calendar.getInstance();
		start.clear();
		start.set(Calendar.MONTH, Calendar.JANUARY);
		start.set(Calendar.DAY_OF_MONTH, 1);
		start.set(Calendar.YEAR, 2018);
		
		Calendar end=Calendar.getInstance();
		end.clear();
		end.set(Calendar.MONTH, Calendar.DECEMBER);
		end.set(Calendar.DAY_OF_MONTH, 31);
		end.set(Calendar.YEAR, 2020);
		
		DateGenerator dateGenerator = new DateGenerator(start, end);
		
		int codiceCorso = randomGenerator.nextInt(20);
		Date data = dateGenerator.generate();
		int voto = 5 + randomGenerator.nextInt(25);

		return new Esame(codiceCorso, studente, data, voto);
	}
	
	
	public static List<Esame> fetchEsamiByCodiceCorso(int codiceCorso) throws SQLException {
		
		Statement statement = DbHelper.getStatement();
		ResultSet rs = statement.executeQuery("SELECT * FROM Esami WHERE codiceCorso = " + codiceCorso);

		List<Esame> esami = new LinkedList<Esame>();		
		while (rs.next()) {
			
			esami.add( new Esame(rs.getInt("codiceCorso"), rs.getInt("studente"),
									rs.getDate("data"), rs.getInt("voto")) );
			
		}
		
		return esami;
	}
	
	
	public static List<Esame> fetchAll() throws SQLException {
		
		Statement statement = DbHelper.getStatement();
		ResultSet rs = statement.executeQuery("SELECT * FROM Esami");

		List<Esame> esami = new LinkedList<Esame>();		
		while (rs.next()) {
			
			esami.add( new Esame(rs.getInt("codiceCorso"), rs.getInt("studente"),
									rs.getDate("data"), rs.getInt("voto")) );
			
		}
		
		return esami;
	}
}
