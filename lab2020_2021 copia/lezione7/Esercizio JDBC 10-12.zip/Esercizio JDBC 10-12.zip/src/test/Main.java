package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import database.DbHelper;
import datamodel.DataModel;
import datamodel.Esame;
import datamodel.Studente;

public class Main {


	public static void main(String[] args) throws SQLException {
		
		Connection connection = DbHelper.getConnection();
		
		// selezionare il contenuto delle tabelle Studenti ed Esami
		List<Studente> studenti = Studente.fetchAll();
		List<Esame> esami = Esame.fetchAll();
		// for	(Studente s : studenti) { System.out.println(s); }
		
		
		
		// selezionare gli studenti che hanno una media > 27 
		// indicando per ciascuno il numero di esami superati 
		// e la relativa media
		
		// Opzione A: Svolgo l'interrogazione sul DBMS, e mappo il ResultSet all'interno di istanze

		Statement statement = DbHelper.getStatement();
		ResultSet rs = statement.executeQuery(
				  "SELECT Studenti.matricola, AVG(voto) as media, COUNT(*) as esamiSuperati "
				+ "FROM Studenti JOIN Esami ON Studenti.matricola=Esami.studente "
				+ "WHERE Esami.voto >= 18 "
				+ "GROUP BY Studenti.matricola "
				+ "HAVING AVG(voto)>27");

		while (rs.next()) {

			int matricola = rs.getInt("matricola");
			double media = rs.getDouble("media");
			int esamiSuperati = rs.getInt("esamiSuperati");
			
			Studente s = Studente.fetchStudente(matricola);
			
			System.out.println(s + " - media: " + media + ", esami superati: " + esamiSuperati);
		}
		
		
		// Opzione B: Svolgo una fetch generica sul DBMS (estraggo tutti gli studenti, per ogni studente estraggo i suoi esami)
		//				e poi lavoro a livello applicativo per calcolare numero di esami superati e media dei voti
		
		
	}
}