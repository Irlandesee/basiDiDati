package datamodel;

import java.util.Random;

import com.googlecode.jeneratedata.people.FemaleNameGenerator;
import com.googlecode.jeneratedata.people.LastNameGenerator;
import com.googlecode.jeneratedata.people.MaleNameGenerator;

public class Studente {

	private int matricola;
	private String cognome;
	private String nome;
	private int eta;
	
	public Studente(int matricola, String cognome, String nome, int eta) {
		
		this.matricola = matricola;
		this.cognome = cognome;
		this.nome = nome;
		this.eta = eta;
	}
	
	public int getMatricola() {
		return matricola;
	}
	public void setMatricola(int matricola) {
		this.matricola = matricola;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getEta() {
		return eta;
	}
	public void setEta(int eta) {
		this.eta = eta;
	}
	
	public static Studente generateStudente() {

		java.util.Random randomGenerator = new Random();
		
		int matricola = randomGenerator.nextInt(999999);
		int eta = randomGenerator.nextInt(30) + 20;

		LastNameGenerator lastNameGenerator = new LastNameGenerator();		
		String cognome = lastNameGenerator.generate();
		String nome;
		
		FemaleNameGenerator femaleNameGenerator = new FemaleNameGenerator();
		MaleNameGenerator maleNameGenerator = new MaleNameGenerator();
		if (randomGenerator.nextInt(100) > 65) {
			nome = maleNameGenerator.generate();
		} else {
			nome = femaleNameGenerator.generate();
		}

		return new Studente(matricola, cognome, nome, eta);
	}
}
