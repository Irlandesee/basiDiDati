package datamodel;

import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import com.googlecode.jeneratedata.dates.DateGenerator;

public class Esame {

	private int codiceCorso;
	private int studente;
	private Date data;
	private int voto;
	
	public Esame(int codiceCorso, int studente, Date data, int voto) {

		this.codiceCorso = codiceCorso;
		this.studente = studente;
		this.data = data;
		this.voto = voto;
	}	
	
	public int getCodiceCorso() {
		return codiceCorso;
	}
	public void setCodiceCorso(int codiceCorso) {
		this.codiceCorso = codiceCorso;
	}
	public int getStudente() {
		return studente;
	}
	public void setStudente(int studente) {
		this.studente = studente;
	}
	public Date getData() {
		return data;
	}
	public void setData(Date data) {
		this.data = data;
	}
	public int getVoto() {
		return voto;
	}
	public void setVoto(int voto) {
		this.voto = voto;
	}

	public static Esame generateEsame(int studente) {

		java.util.Random randomGenerator = new Random();

		Calendar start=Calendar.getInstance();
		start.clear();
		start.set(Calendar.MONTH, Calendar.JANUARY);
		start.set(Calendar.DAY_OF_MONTH, 1);
		start.set(Calendar.YEAR, 2018);
		
		Calendar end=Calendar.getInstance();
		end.clear();
		end.set(Calendar.MONTH, Calendar.DECEMBER);
		end.set(Calendar.DAY_OF_MONTH, 31);
		end.set(Calendar.YEAR, 2020);
		
		DateGenerator dateGenerator = new DateGenerator(start, end);
		
		int codiceCorso = randomGenerator.nextInt(20);
		Date data = dateGenerator.generate();
		int voto = 5 + randomGenerator.nextInt(25);

		return new Esame(codiceCorso, studente, data, voto);
	}
	
}
