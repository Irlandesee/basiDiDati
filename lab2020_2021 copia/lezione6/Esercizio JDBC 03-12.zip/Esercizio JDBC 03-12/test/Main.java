package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;

import datamodel.DataModel;
import datamodel.Esame;
import datamodel.Studente;

public class Main {

	public static void main(String[] args) throws SQLException {
		
		// Uniform resource locator
		String protocol = "jdbc:postgresql" + "://";
		String host = "localhost/";
		String resource = "Studenti";
		String url = protocol + host + resource;
		
		String username = "postgres";
		String password = " --- ";
		
		java.sql.Connection connection = DriverManager.getConnection(url, username, password);
		java.sql.Statement statement = connection.createStatement();

		// Cancellazione delle tabelle
		String[] drops = {"DROP TABLE IF EXISTS Esami", "DROP TABLE IF EXISTS Studenti"};
		for (String query : drops)
			System.out.println("Risultato di DROP: " + statement.executeUpdate(query));

		
		// Creazione delle tabelle
		String query = "CREATE TABLE Studenti ("
						+ "matricola NUMERIC PRIMARY KEY,"
						+ "cognome VARCHAR(50) NOT NULL,"
						+ "nome VARCHAR(50) NOT NULL,"
						+ "eta NUMERIC(3)"
					 + ");";
		
		System.out.println("Risultato di CREATE: " + statement.executeUpdate(query));

	
		query = "CREATE TABLE Esami ("
				+ "codiceCorso NUMERIC NOT NULL,"
				+ "studente NUMERIC NOT NULL REFERENCES Studenti(matricola),"
				+ "data DATE NOT NULL,"
				+ "voto NUMERIC NOT NULL,"
				+ "PRIMARY KEY (codiceCorso, studente, data)"
			  + ");";

		System.out.println("Risultato di CREATE: " + statement.executeUpdate(query));
		

		DataModel dataModel = new DataModel();
		dataModel.populateModel(50, 200);
		
		PreparedStatement prepared = connection.prepareStatement("INSERT INTO Studenti(matricola, cognome, nome, eta) VALUES (?,?,?,?)");
		for (Studente s : dataModel.getStudenti()) {
			
			prepared.setInt(1, s.getMatricola());
			prepared.setString(2, s.getCognome());
			prepared.setString(3, s.getNome());
			prepared.setInt(4, s.getEta());
			
			prepared.executeUpdate();
		}
		
		
		prepared = connection.prepareStatement("INSERT INTO Esami(codiceCorso, studente, data, voto) VALUES (?,?,?,?)");
		for (Esame e : dataModel.getEsami()) {

			prepared.setInt(1, e.getCodiceCorso() );
			prepared.setInt(2, e.getStudente() );
			prepared.setDate(3, new java.sql.Date(e.getData().getTime()));
			prepared.setInt(4, e.getVoto());
			
			prepared.executeUpdate();
		}
	}
}